# Assured Contract Farming System for Farmers
Full-stack academic starter project connecting farmers and buyers.

## Stack
React + Vite, Node.js + Express, MySQL, JWT authentication.

## Features
- Farmer and buyer registration/login
- Farmer crop listings
- Buyer marketplace and contract proposals
- Farmer accepts/rejects proposals and marks accepted contracts complete
- MySQL persistence

## Run locally
1. Install Node.js 18+ and MySQL 8+.
2. Run `database/schema.sql` in MySQL Workbench.
3. In `backend`, copy `.env.example` to `.env`, update MySQL credentials and set a long random `JWT_SECRET`; run `npm install` then `npm run dev`.
4. In another terminal, enter `frontend`; run `npm install` then `npm run dev`.
5. Open the Vite URL, normally http://localhost:5173.
6. Register a farmer and a buyer account to test both roles.

This is a student prototype. Contract proposals are not legally binding. Do not commit `.env`, secrets, or real personal data. For production, add HTTPS, rate limiting, secure cookie-based sessions, email verification, audit logs and legal review.
