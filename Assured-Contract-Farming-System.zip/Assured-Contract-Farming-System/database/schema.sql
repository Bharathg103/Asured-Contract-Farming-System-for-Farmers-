CREATE DATABASE IF NOT EXISTS assured_farming CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE assured_farming;
CREATE TABLE IF NOT EXISTS users (
 id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL,
 email VARCHAR(150) NOT NULL UNIQUE, password_hash VARCHAR(255) NOT NULL,
 role ENUM('farmer','buyer') NOT NULL, phone VARCHAR(25), location VARCHAR(150),
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS crops (
 id INT AUTO_INCREMENT PRIMARY KEY, farmer_id INT NOT NULL,
 crop_name VARCHAR(100) NOT NULL, quantity_kg DECIMAL(12,2) NOT NULL,
 price_per_kg DECIMAL(12,2) NOT NULL, location VARCHAR(150) NOT NULL,
 harvest_date DATE NULL, description TEXT,
 status ENUM('available','reserved','closed') DEFAULT 'available',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (farmer_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS contracts (
 id INT AUTO_INCREMENT PRIMARY KEY, crop_id INT NOT NULL, farmer_id INT NOT NULL, buyer_id INT NOT NULL,
 quantity_kg DECIMAL(12,2) NOT NULL, agreed_price_per_kg DECIMAL(12,2) NOT NULL,
 total_amount DECIMAL(14,2) NOT NULL, delivery_date DATE NULL, terms TEXT,
 status ENUM('proposed','accepted','rejected','completed') DEFAULT 'proposed',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (crop_id) REFERENCES crops(id) ON DELETE CASCADE,
 FOREIGN KEY (farmer_id) REFERENCES users(id) ON DELETE CASCADE,
 FOREIGN KEY (buyer_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX idx_crops_status ON crops(status);
CREATE INDEX idx_contracts_farmer ON contracts(farmer_id);
CREATE INDEX idx_contracts_buyer ON contracts(buyer_id);
